TEMP_DIR = '/app/tmp'

OUTPUT_DIR = '/app/tmp2'
OUTPUT_DIR = '/app/tmp'

ALLOWED_EXTENSIONS = {'pdf'}

ALLOWED_EXTENSIONS_TO_CONVERT = {'docx', 'xlsx', 'pptx', 'odt'}